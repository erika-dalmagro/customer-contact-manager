

<?php $__env->startSection('content'); ?>
<div class="space">
   <h1 class="ui center aligned header"> Listagem de Clientes </h1>
   <div class="ui container">
      <div class="ul list-group">
         <?php if($cliente->count() > 0): ?>
         <table class="table">
            <thead>
               <tr>
                  <th>Nome Fantasia</th>
                  <th>Tipo de Pessoa</th>
                  <th>Status</th>
                  <th>
                     <i class="fa fa-cog centralizar"></i>
                  </th>
               </tr>
            </thead>
            <tbody>
               <?php $__currentLoopData = $cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <tr>
                  <td><?php echo e($cliente->nome_fantasia); ?></td>
                  <td><?php echo e($cliente->tipo_pessoa); ?></td>
                  <td><?php echo e($cliente->status); ?></td>
                  <td class="centralizar">
                     <a href="<?php echo e(route('cliente.detalhar', $cliente->id)); ?>" class="btn center aligned btn-outline-primary ui button">
                        Detalhes
                     </a>
                     <a href="<?php echo e(route('cliente.excluir', $cliente->id)); ?>" class="btn center aligned btn-outline-primary ui button" onclick="return confirm('Tem certeza que deseja excluir?')">
                        Excluir
                     </a>

                  </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               <?php else: ?>
               <h3 class="ui center aligned header"> Nenhum cliente cadastrado!</h3>
               <?php endif; ?>
            </tbody>
         </table>

      </div>
      <br>
      <div class="centro">
         <a class="btn btn-outline-primary ui button" href="<?php echo e(route('cliente.adicionar')); ?>"> Cadastrar Cliente</a>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lika-\Desktop\trabalho_php\resources\views/cliente/index.blade.php ENDPATH**/ ?>