

<?php $__env->startSection('content'); ?>
<div class="space">
    <h1 class="ui center aligned header"> Detalhes </h1>
    <div class="ui container">
        <table class="table ui celled center aligned">
            <thead>
                <tr>
                    <th> Razão Social </th>
                    <th> Nome Fantasia </th>
                    <th> Tipo Pessoa</th>
                    <th> Documento </th>
                    <th> Estado </th>
                    <th> Cidade </th>
                    <th> E-mail </th>
                    <th> Telefone </th>
                    <th> Endereço </th>
                    <th> Status </th>
                    <th> Ações </th>
                </tr>
            <tbody>

                <tr>
                    <td> <?php echo e($cliente -> razao_social); ?> </td>
                    <td> <?php echo e($cliente -> nome_fantasia); ?> </td>
                    <td> <?php echo e($cliente -> tipo_pessoa); ?> </td>
                    <td> <?php echo e($cliente -> documento); ?> </td>
                    <td> <?php echo e($cliente -> estado); ?> </td>
                    <td> <?php echo e($cliente -> cidade); ?> </td>
                    <td> <?php echo e($cliente -> email); ?> </td>
                    <td> <?php echo e($cliente -> telefone); ?> </td>
                    <td> <?php echo e($cliente -> endereco); ?> </td>
                    <td> <?php echo e($cliente -> status); ?> </td>
                    <td>
                        <a class="btn button" href="<?php echo e(route('cliente.editar', $cliente->id)); ?>">
                            <i class="fa fa-pencil-alt"></i>
                        </a>
                        <a class="btn button" onclick="return confirm('Tem certeza que deseja excluir?')" href="<?php echo e(route('cliente.excluir', $cliente->id)); ?>">
                            <i class="fa fa-times"></i>
                        </a>
                    </td>
                </tr>

            </tbody>
        </table>

        <h1 class="ui center aligned header"> Contato </h1>


        <?php if($contato->count() > 0): ?>
        <table class="table ui celled center aligned">
            <thead>
                <tr>
                    <th> Nome </th>
                    <th> E-mail </th>
                    <th> Telefone </th>
                    <th> Função </th>
                    <th> Ações </th>
                </tr>
            <tbody>
                <?php $__currentLoopData = $contato; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td> <?php echo e($contato->nome); ?> </td>
                    <td> <?php echo e($contato -> email); ?> </td>
                    <td> <?php echo e($contato -> telefone); ?> </td>
                    <td> <?php echo e($contato -> funcao); ?> </td>
                    <td>
                        <a class="btn ui button" href="<?php echo e(route('contato.editar', $contato->id)); ?>">
                            <i class="fa fa-pencil-alt"></i>
                        </a>
                        <a class="btn ui button" onclick="return confirm('Tem certeza que deseja excluir?')" href="<?php echo e(route('contato.excluir', $contato->id)); ?>">
                            <i class="fa fa-times"></i>
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <?php else: ?>
        <h3 class="ui center aligned header">
            Nenhum contato cadastrado
        </h3>
        <?php endif; ?>
        <div class="centro">
            <a class="btn center aligned btn-outline-primary ui button" href="<?php echo e(route('contato.adicionar', $cliente->id)); ?>"> Cadastrar contato </a>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('topnav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lika-\Desktop\trabalho_php\resources\views/cliente/detalhar.blade.php ENDPATH**/ ?>